import 'package:cloud_firestore/cloud_firestore.dart';

enum UserRole { customer, admin }

class UserProfile {
  const UserProfile({
    required this.id,
    required this.email,
    required this.displayName,
    required this.role,
    this.phone = '',
    this.createdAt,
    this.notificationTokens = const [],
  });

  final String id;
  final String email;
  final String displayName;
  final UserRole role;
  final String phone;
  final DateTime? createdAt;
  final List<String> notificationTokens;

  bool get isAdmin => role == UserRole.admin;

  factory UserProfile.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return UserProfile(
      id: doc.id,
      email: data['email'] as String? ?? '',
      displayName: data['displayName'] as String? ?? 'Queue user',
      role: data['role'] == 'admin' ? UserRole.admin : UserRole.customer,
      phone: data['phone'] as String? ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      notificationTokens:
          (data['notificationTokens'] as List<dynamic>? ?? []).cast<String>(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'email': email,
        'displayName': displayName,
        'role': role.name,
        'phone': phone,
        'createdAt': createdAt == null
            ? FieldValue.serverTimestamp()
            : Timestamp.fromDate(createdAt!),
        'notificationTokens': notificationTokens,
      };
}