import 'package:cloud_firestore/cloud_firestore.dart';

class QueueModel {
  const QueueModel({
    required this.id,
    required this.name,
    required this.location,
    required this.description,
    required this.ownerId,
    required this.currentNumber,
    required this.lastIssuedNumber,
    required this.averageServiceMinutes,
    required this.isActive,
    this.createdAt,
    this.color = 0xFF1457D9,
  });

  final String id;
  final String name;
  final String location;
  final String description;
  final String ownerId;
  final int currentNumber;
  final int lastIssuedNumber;
  final int averageServiceMinutes;
  final bool isActive;
  final DateTime? createdAt;
  final int color;

  int get waitingCount => lastIssuedNumber - currentNumber;
  bool get hasWaitingCustomers => waitingCount > 0;

  factory QueueModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return QueueModel(
      id: doc.id,
      name: data['name'] as String? ?? 'Unnamed queue',
      location: data['location'] as String? ?? '',
      description: data['description'] as String? ?? '',
      ownerId: data['ownerId'] as String? ?? '',
      currentNumber: (data['currentNumber'] as num?)?.toInt() ?? 0,
      lastIssuedNumber: (data['lastIssuedNumber'] as num?)?.toInt() ?? 0,
      averageServiceMinutes:
          (data['averageServiceMinutes'] as num?)?.toInt() ?? 5,
      isActive: data['isActive'] as bool? ?? true,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      color: (data['color'] as num?)?.toInt() ?? 0xFF1457D9,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'name': name,
        'location': location,
        'description': description,
        'ownerId': ownerId,
        'currentNumber': currentNumber,
        'lastIssuedNumber': lastIssuedNumber,
        'averageServiceMinutes': averageServiceMinutes,
        'isActive': isActive,
        'color': color,
        'createdAt': FieldValue.serverTimestamp(),
      };
}