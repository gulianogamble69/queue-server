import 'package:cloud_firestore/cloud_firestore.dart';

enum TicketStatus { waiting, inService, served, cancelled }

class TicketModel {
  const TicketModel({
    required this.id,
    required this.queueId,
    required this.queueName,
    required this.userId,
    required this.number,
    required this.status,
    this.joinedAt,
    this.completedAt,
  });

  final String id;
  final String queueId;
  final String queueName;
  final String userId;
  final int number;
  final TicketStatus status;
  final DateTime? joinedAt;
  final DateTime? completedAt;

  factory TicketModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return TicketModel(
      id: doc.id,
      queueId: data['queueId'] as String? ?? '',
      queueName: data['queueName'] as String? ?? 'Queue',
      userId: data['userId'] as String? ?? '',
      number: (data['number'] as num?)?.toInt() ?? 0,
      status: TicketStatus.values.firstWhere(
        (value) => value.name == data['status'],
        orElse: () => TicketStatus.waiting,
      ),
      joinedAt: (data['joinedAt'] as Timestamp?)?.toDate(),
      completedAt: (data['completedAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'queueId': queueId,
        'queueName': queueName,
        'userId': userId,
        'number': number,
        'status': status.name,
        'joinedAt': FieldValue.serverTimestamp(),
      };
}