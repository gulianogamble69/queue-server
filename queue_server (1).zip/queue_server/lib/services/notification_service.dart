import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await FirebaseMessaging.instance.getInitialMessage();
}

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final _messaging = FirebaseMessaging.instance;
  final _local = FlutterLocalNotificationsPlugin();
  static const _channel = AndroidNotificationChannel(
    'queue_updates',
    'Queue updates',
    description: 'Alerts about queue position and service updates.',
    importance: Importance.high,
  );

  Future<void> initialize() async {
    await _messaging.requestPermission(alert: true, badge: true, sound: true);
    await _local
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_channel);
    await _local.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
    );
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    FirebaseMessaging.onMessage.listen(_showForegroundMessage);
  }

  Future<void> registerDevice(String uid) async {
    final token = await _messaging.getToken();
    if (token == null) return;
    await FirebaseFirestore.instance.collection('users').doc(uid).set(
      {
        'notificationTokens': FieldValue.arrayUnion([token]),
      },
      SetOptions(merge: true),
    );
    _messaging.onTokenRefresh.listen((newToken) {
      FirebaseFirestore.instance.collection('users').doc(uid).set(
        {
          'notificationTokens': FieldValue.arrayUnion([newToken]),
        },
        SetOptions(merge: true),
      );
    });
  }

  Future<void> _showForegroundMessage(RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return Future.value();
    return _local.show(
      notification.hashCode,
      notification.title,
      notification.body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'queue_updates',
          'Queue updates',
          channelDescription: 'Alerts about queue position and service updates.',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }
}