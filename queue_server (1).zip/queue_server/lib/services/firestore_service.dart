import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/queue_model.dart';
import '../models/ticket_model.dart';

class FirestoreService {
  FirestoreService._();
  static final instance = FirestoreService._();

  final _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _queues =>
      _db.collection('queues');
  CollectionReference<Map<String, dynamic>> get _tickets =>
      _db.collection('tickets');

  Stream<List<QueueModel>> watchActiveQueues() {
    return _queues
        .where('isActive', isEqualTo: true)
        .orderBy('name')
        .snapshots()
        .map((snapshot) => snapshot.docs.map(QueueModel.fromFirestore).toList());
  }

  Stream<List<QueueModel>> watchAdminQueues(String ownerId) {
    return _queues
        .where('ownerId', isEqualTo: ownerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map(QueueModel.fromFirestore).toList());
  }

  Stream<QueueModel> watchQueue(String queueId) {
    return _queues.doc(queueId).snapshots().map(QueueModel.fromFirestore);
  }

  Stream<List<TicketModel>> watchUserTickets(String userId) {
    return _tickets
        .where('userId', isEqualTo: userId)
        .orderBy('joinedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map(TicketModel.fromFirestore).toList());
  }

  Stream<List<TicketModel>> watchQueueTickets(String queueId) {
    return _tickets
        .where('queueId', isEqualTo: queueId)
        .where('status', whereIn: ['waiting', 'inService'])
        .orderBy('number')
        .snapshots()
        .map((snapshot) => snapshot.docs.map(TicketModel.fromFirestore).toList());
  }

  Future<String> createQueue({
    required String name,
    required String location,
    required String description,
    required int averageServiceMinutes,
    required int color,
  }) async {
    final ownerId = FirebaseAuth.instance.currentUser!.uid;
    final ref = _queues.doc();
    await ref.set(
      QueueModel(
        id: ref.id,
        name: name.trim(),
        location: location.trim(),
        description: description.trim(),
        ownerId: ownerId,
        currentNumber: 0,
        lastIssuedNumber: 0,
        averageServiceMinutes: averageServiceMinutes,
        isActive: true,
        color: color,
      ).toFirestore(),
    );
    return ref.id;
  }

  Future<TicketModel> joinQueue(QueueModel queue, String userId) async {
    final queueRef = _queues.doc(queue.id);
    final ticketNumber = await _db.runTransaction<int>((transaction) async {
      final snapshot = await transaction.get(queueRef);
      if (!snapshot.exists) {
        throw StateError('This queue no longer exists.');
      }
      final data = snapshot.data()!;
      if (data['isActive'] != true) {
        throw StateError('This queue is not accepting customers.');
      }
      final next = ((data['lastIssuedNumber'] as num?)?.toInt() ?? 0) + 1;
      transaction.update(queueRef, {'lastIssuedNumber': next});
      return next;
    });

    final ticketId = '${queue.id}_$ticketNumber';
    final ticketRef = _tickets.doc(ticketId);
    final ticket = TicketModel(
      id: ticketId,
      queueId: queue.id,
      queueName: queue.name,
      userId: userId,
      number: ticketNumber,
      status: TicketStatus.waiting,
      joinedAt: DateTime.now(),
    );
    await ticketRef.set(ticket.toFirestore());
    return ticket;
  }

  Future<void> cancelTicket(String ticketId) async {
    await _tickets.doc(ticketId).update({
      'status': TicketStatus.cancelled.name,
      'completedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> advanceQueue(QueueModel queue) async {
    if (!queue.hasWaitingCustomers) return;
    final nextNumber = queue.currentNumber + 1;
    await _db.runTransaction((transaction) async {
      final queueSnapshot = await transaction.get(_queues.doc(queue.id));
      final current = (queueSnapshot.data()?['currentNumber'] as num?)?.toInt() ?? 0;
      transaction.update(_queues.doc(queue.id), {'currentNumber': current + 1});
    });
    final nextTicket = await _tickets
        .where('queueId', isEqualTo: queue.id)
        .where('number', isEqualTo: nextNumber)
        .limit(1)
        .get();
    if (nextTicket.docs.isNotEmpty) {
      await nextTicket.docs.first.reference.update({
        'status': TicketStatus.inService.name,
      });
    }
    final previousTickets = await _tickets
        .where('queueId', isEqualTo: queue.id)
        .where('number', isLessThan: nextNumber)
        .where('status', whereIn: ['waiting', 'inService'])
        .get();
    if (previousTickets.docs.isNotEmpty) {
      final batch = _db.batch();
      for (final ticket in previousTickets.docs) {
        batch.update(ticket.reference, {
          'status': TicketStatus.served.name,
          'completedAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();
    }
  }

  Future<void> setQueueActive(String queueId, bool isActive) {
    return _queues.doc(queueId).update({'isActive': isActive});
  }

  Future<void> deleteQueue(String queueId) => _queues.doc(queueId).delete();
}