import 'package:intl/intl.dart';

String formatDate(DateTime? date) {
  if (date == null) return 'Just now';
  return DateFormat('MMM d, yyyy • h:mm a').format(date);
}

String formatShortDate(DateTime? date) {
  if (date == null) return 'Today';
  return DateFormat('MMM d, h:mm a').format(date);
}