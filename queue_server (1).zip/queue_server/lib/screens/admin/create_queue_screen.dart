import 'package:flutter/material.dart';

import '../../services/firestore_service.dart';

class CreateQueueScreen extends StatefulWidget {
  const CreateQueueScreen({super.key});

  @override
  State<CreateQueueScreen> createState() => _CreateQueueScreenState();
}

class _CreateQueueScreenState extends State<CreateQueueScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _location = TextEditingController();
  final _description = TextEditingController();
  int _serviceMinutes = 5;
  int _color = 0xFF1457D9;
  bool _loading = false;
  final _colors = const [
    0xFF1457D9,
    0xFF0E9F6E,
    0xFFE38524,
    0xFF8B5CF6,
    0xFFE14D66,
  ];

  @override
  void dispose() {
    _name.dispose();
    _location.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await FirestoreService.instance.createQueue(
        name: _name.text,
        location: _location.text,
        description: _description.text,
        averageServiceMinutes: _serviceMinutes,
        color: _color,
      );
      if (mounted) Navigator.of(context).pop();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not create queue: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create queue')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(22, 10, 22, 28),
            children: [
              Text(
                'Set up a line',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 7),
              Text(
                'Customers will see this queue as soon as you publish it.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 25),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(
                  labelText: 'Queue name',
                  hintText: 'e.g. General services',
                  prefixIcon: Icon(Icons.label_outline_rounded),
                ),
                validator: (v) => v == null || v.trim().isEmpty
                    ? 'Give your queue a name'
                    : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _location,
                decoration: const InputDecoration(
                  labelText: 'Location',
                  hintText: 'e.g. Downtown branch • Counter 2',
                  prefixIcon: Icon(Icons.location_on_outlined),
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _description,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description (optional)',
                  hintText: 'Tell customers what this queue is for',
                  prefixIcon: Icon(Icons.notes_rounded),
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Average service time',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<int>(
                value: _serviceMinutes,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.schedule_rounded),
                ),
                items: [3, 5, 10, 15, 20, 30]
                    .map(
                      (minutes) => DropdownMenuItem(
                        value: minutes,
                        child: Text('$minutes minutes per customer'),
                      ),
                    )
                    .toList(),
                onChanged: (value) =>
                    setState(() => _serviceMinutes = value ?? 5),
              ),
              const SizedBox(height: 24),
              Text(
                'Queue color',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
              ),
              const SizedBox(height: 12),
              Row(
                children: _colors
                    .map(
                      (color) => Padding(
                        padding: const EdgeInsets.only(right: 14),
                        child: InkWell(
                          onTap: () => setState(() => _color = color),
                          borderRadius: BorderRadius.circular(24),
                          child: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: Color(color),
                              shape: BoxShape.circle,
                              border: _color == color
                                  ? Border.all(color: Colors.white, width: 3)
                                  : null,
                              boxShadow: _color == color
                                  ? [
                                      BoxShadow(
                                        color: Color(color).withOpacity(.4),
                                        blurRadius: 0,
                                        spreadRadius: 3,
                                      ),
                                    ]
                                  : null,
                            ),
                            child: _color == color
                                ? const Icon(
                                    Icons.check_rounded,
                                    color: Colors.white,
                                    size: 19,
                                  )
                                : null,
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _loading ? null : _create,
                child: _loading
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Text('Publish queue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}