import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../models/queue_model.dart';
import '../../models/ticket_model.dart';
import '../../services/firestore_service.dart';
import '../../widgets/section_heading.dart';
import 'create_queue_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return SafeArea(
      child: StreamBuilder<List<QueueModel>>(
        stream: FirestoreService.instance.watchAdminQueues(user!.uid),
        builder: (context, snapshot) {
          final queues = snapshot.data ?? [];
          final totalWaiting = queues.fold<int>(
            0,
            (sum, queue) => sum + queue.waitingCount,
          );
          return CustomScrollView(
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 0),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Business overview',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              'Keep every customer moving forward.',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      IconButton.filledTonal(
                        onPressed: () => _openCreate(context),
                        icon: const Icon(Icons.add_rounded),
                        tooltip: 'Create queue',
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 24, 22, 0),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: [
                      Expanded(
                        child: _MetricCard(
                          value: '${queues.length}',
                          label: 'Active queues',
                          icon: Icons.view_list_rounded,
                          color: const Color(0xFF1457D9),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _MetricCard(
                          value: '$totalWaiting',
                          label: 'Customers waiting',
                          icon: Icons.people_alt_rounded,
                          color: const Color(0xFF0E9F6E),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 28, 22, 12),
                sliver: SliverToBoxAdapter(
                  child: SectionHeading(
                    title: 'Your queues',
                    actionLabel: 'New queue',
                    onAction: () => _openCreate(context),
                  ),
                ),
              ),
              if (snapshot.connectionState == ConnectionState.waiting)
                const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (queues.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: _EmptyAdminState(onCreate: () => _openCreate(context)),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(22, 0, 22, 28),
                  sliver: SliverList.separated(
                    itemCount: queues.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) =>
                        _AdminQueueCard(queue: queues[index]),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _openCreate(BuildContext context) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const CreateQueueScreen()),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });
  final String value;
  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 17),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
            const SizedBox(height: 2),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class _AdminQueueCard extends StatelessWidget {
  const _AdminQueueCard({required this.queue});
  final QueueModel queue;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<TicketModel>>(
      stream: FirestoreService.instance.watchQueueTickets(queue.id),
      builder: (context, snapshot) {
        final tickets = snapshot.data ?? [];
        final inService = tickets.where(
          (ticket) => ticket.status == TicketStatus.inService,
        );
        final current = inService.isNotEmpty ? inService.first.number : null;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(17),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: queue.isActive ? Colors.green : Colors.grey,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        queue.name,
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontWeight: FontWeight.w800),
                      ),
                    ),
                    PopupMenuButton<String>(
                      onSelected: (value) => _handleMenu(context, value),
                      itemBuilder: (_) => [
                        PopupMenuItem(
                          value: queue.isActive ? 'pause' : 'resume',
                          child: Text(queue.isActive ? 'Pause queue' : 'Resume queue'),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Text('Delete queue'),
                        ),
                      ],
                    ),
                  ],
                ),
                if (queue.location.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      queue.location,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ],
                const SizedBox(height: 17),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _QueueValue(
                          label: 'Now serving',
                          value: current == null ? '—' : '#$current',
                        ),
                      ),
                      Expanded(
                        child: _QueueValue(
                          label: 'Waiting',
                          value: '${queue.waitingCount}',
                        ),
                      ),
                      Expanded(
                        child: _QueueValue(
                          label: 'Issued today',
                          value: '${queue.lastIssuedNumber}',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                ElevatedButton.icon(
                  onPressed: queue.hasWaitingCustomers
                      ? () => FirestoreService.instance.advanceQueue(queue)
                      : null,
                  icon: const Icon(Icons.skip_next_rounded),
                  label: Text(
                    queue.hasWaitingCustomers
                        ? 'Call next customer'
                        : 'No customers waiting',
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _handleMenu(BuildContext context, String value) async {
    if (value == 'pause' || value == 'resume') {
      await FirestoreService.instance.setQueueActive(queue.id, value == 'resume');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete queue?'),
        content: const Text(
          'This removes the queue from your business. Existing tickets remain in history.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await FirestoreService.instance.deleteQueue(queue.id);
    }
  }
}

class _QueueValue extends StatelessWidget {
  const _QueueValue({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.labelSmall),
        const SizedBox(height: 5),
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w900,
              ),
        ),
      ],
    );
  }
}

class _EmptyAdminState extends StatelessWidget {
  const _EmptyAdminState({required this.onCreate});
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.add_business_rounded,
              size: 54,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 14),
            Text(
              'Create your first queue',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 5),
            const Text(
              'Set up a line for your customers and let Queue Server handle the rest.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: onCreate,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Create queue'),
            ),
          ],
        ),
      ),
    );
  }
}