import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../models/queue_model.dart';
import '../../models/ticket_model.dart';
import '../../services/firestore_service.dart';
import '../../widgets/section_heading.dart';
import '../ticket/ticket_screen.dart';

class CustomerDashboard extends StatelessWidget {
  const CustomerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final greeting = user?.displayName?.split(' ').first ?? 'there';
    return SafeArea(
      child: StreamBuilder<List<TicketModel>>(
        stream: FirestoreService.instance.watchUserTickets(user!.uid),
        builder: (context, ticketSnapshot) {
          final activeTickets = (ticketSnapshot.data ?? [])
              .where((ticket) =>
                  ticket.status == TicketStatus.waiting ||
                  ticket.status == TicketStatus.inService)
              .toList();
          return StreamBuilder<List<QueueModel>>(
            stream: FirestoreService.instance.watchActiveQueues(),
            builder: (context, queueSnapshot) {
              final queues = queueSnapshot.data ?? [];
              return CustomScrollView(
                slivers: [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(22, 22, 22, 0),
                    sliver: SliverToBoxAdapter(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Good day, $greeting',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineSmall
                                      ?.copyWith(fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  activeTickets.isEmpty
                                      ? 'Ready when you are.'
                                      : 'Your place in line is waiting.',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onSurfaceVariant,
                                      ),
                                ),
                              ],
                            ),
                          ),
                          CircleAvatar(
                            radius: 22,
                            backgroundColor:
                                Theme.of(context).colorScheme.primaryContainer,
                            child: Text(
                              (greeting.isNotEmpty ? greeting[0] : 'Q')
                                  .toUpperCase(),
                              style: TextStyle(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onPrimaryContainer,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (activeTickets.isNotEmpty)
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(22, 26, 22, 0),
                      sliver: SliverToBoxAdapter(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SectionHeading(title: 'Your active tickets'),
                            const SizedBox(height: 10),
                            ...activeTickets.map(
                              (ticket) => Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: _ActiveTicketCard(ticket: ticket),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(22, 26, 22, 12),
                    sliver: SliverToBoxAdapter(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const SectionHeading(title: 'Available queues'),
                          Text(
                            '${queues.length} open',
                            style: Theme.of(context).textTheme.labelMedium?.copyWith(
                                  color: Theme.of(context).colorScheme.primary,
                                  fontWeight: FontWeight.w700,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (queueSnapshot.connectionState == ConnectionState.waiting)
                    const SliverFillRemaining(
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (queues.isEmpty)
                    const SliverFillRemaining(
                      hasScrollBody: false,
                      child: _EmptyQueues(),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(22, 0, 22, 28),
                      sliver: SliverList.separated(
                        itemCount: queues.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) => _QueueCard(
                          queue: queues[index],
                          activeTicket: activeTickets.firstWhere(
                            (ticket) => ticket.queueId == queues[index].id,
                            orElse: () => const TicketModel(
                              id: '',
                              queueId: '',
                              queueName: '',
                              userId: '',
                              number: 0,
                              status: TicketStatus.cancelled,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _ActiveTicketCard extends StatelessWidget {
  const _ActiveTicketCard({required this.ticket});
  final TicketModel ticket;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QueueModel>(
      stream: FirestoreService.instance.watchQueue(ticket.queueId),
      builder: (context, snapshot) {
        final queue = snapshot.data;
        final place = queue == null
            ? 0
            : (ticket.number - queue.currentNumber).clamp(0, 999);
        final wait = queue == null ? 0 : place * queue.averageServiceMinutes;
        return InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => TicketScreen(ticket: ticket),
            ),
          ),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1457D9), Color(0xFF247BD9)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF1457D9).withOpacity(.24),
                  blurRadius: 20,
                  offset: const Offset(0, 9),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.16),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'TICKET',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                      Text(
                        '#${ticket.number}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        ticket.queueName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        ticket.status == TicketStatus.inService
                            ? 'You are being served now'
                            : '$place ${place == 1 ? 'person' : 'people'} ahead • ~$wait min',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: Colors.white),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _QueueCard extends StatelessWidget {
  const _QueueCard({required this.queue, required this.activeTicket});
  final QueueModel queue;
  final TicketModel activeTicket;

  @override
  Widget build(BuildContext context) {
    final alreadyJoined = activeTicket.id.isNotEmpty;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: alreadyJoined
            ? () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => TicketScreen(ticket: activeTicket),
                  ),
                )
            : () => _join(context),
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Color(queue.color).withOpacity(.1),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(
                  Icons.storefront_rounded,
                  color: Color(queue.color),
                ),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      queue.name,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                    if (queue.location.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        queue.location,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceVariant,
                            ),
                      ),
                    ],
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          Icons.people_alt_outlined,
                          size: 15,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${queue.waitingCount} waiting',
                          style: Theme.of(context).textTheme.labelSmall,
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          Icons.schedule_rounded,
                          size: 15,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '~${queue.waitingCount * queue.averageServiceMinutes} min',
                          style: Theme.of(context).textTheme.labelSmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Icon(
                alreadyJoined
                    ? Icons.confirmation_number_rounded
                    : Icons.add_circle_outline_rounded,
                color: Theme.of(context).colorScheme.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _join(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final ticket = await FirestoreService.instance.joinQueue(queue, user.uid);
      if (!context.mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => TicketScreen(ticket: ticket)),
      );
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
        );
      }
    }
  }
}

class _EmptyQueues extends StatelessWidget {
  const _EmptyQueues();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.event_available_rounded,
              size: 58,
              color: Theme.of(context).colorScheme.primary.withOpacity(.7),
            ),
            const SizedBox(height: 14),
            Text(
              'No queues are open right now',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 5),
            Text(
              'Check back soon or ask the business to open a queue.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}