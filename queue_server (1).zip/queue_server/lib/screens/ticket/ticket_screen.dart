import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../models/queue_model.dart';
import '../../models/ticket_model.dart';
import '../../services/firestore_service.dart';
import '../../utils/app_formatters.dart';

class TicketScreen extends StatelessWidget {
  const TicketScreen({super.key, required this.ticket});
  final TicketModel ticket;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your ticket'),
        actions: [
          IconButton(
            tooltip: 'Close',
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close_rounded),
          ),
        ],
      ),
      body: StreamBuilder<QueueModel>(
        stream: FirestoreService.instance.watchQueue(ticket.queueId),
        builder: (context, snapshot) {
          final queue = snapshot.data;
          final place = queue == null
              ? 0
              : (ticket.number - queue.currentNumber).clamp(0, 999);
          final wait = queue == null ? 0 : place * queue.averageServiceMinutes;
          final isServing = ticket.status == TicketStatus.inService ||
              queue?.currentNumber == ticket.number;
          return ListView(
            padding: const EdgeInsets.fromLTRB(22, 10, 22, 28),
            children: [
              Text(
                ticket.queueName,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 5),
              Text(
                queue?.location ?? 'Live queue ticket',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
              const SizedBox(height: 22),
              Container(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Theme.of(context).dividerColor),
                ),
                child: Column(
                  children: [
                    Text(
                      isServing ? 'NOW SERVING' : 'YOUR NUMBER',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: isServing
                                ? Colors.green.shade700
                                : Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '#${ticket.number}',
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                            fontWeight: FontWeight.w900,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: QrImageView(
                        data: 'queueserver://ticket/${ticket.id}',
                        version: QrVersions.auto,
                        size: 168,
                        eyeStyle: const QrEyeStyle(
                          eyeShape: QrEyeShape.square,
                          color: Color(0xFF0B1F3A),
                        ),
                        dataModuleStyle: const QrDataModuleStyle(
                          dataModuleShape: QrDataModuleShape.square,
                          color: Color(0xFF0B1F3A),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Show this QR code at the counter',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _StatTile(
                      icon: Icons.people_alt_outlined,
                      label: 'Ahead of you',
                      value: isServing ? '0' : '$place',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _StatTile(
                      icon: Icons.schedule_rounded,
                      label: 'Est. wait',
                      value: isServing ? 'Now' : '~$wait min',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(17),
                  child: Row(
                    children: [
                      Icon(
                        Icons.access_time_rounded,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(width: 13),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isServing
                                  ? 'Please proceed to the counter'
                                  : 'We will notify you when you are close',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(fontWeight: FontWeight.w800),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Joined ${formatShortDate(ticket.joinedAt)}',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (ticket.status == TicketStatus.waiting) ...[
                const SizedBox(height: 22),
                OutlinedButton(
                  onPressed: () => _cancel(context),
                  child: const Text('Leave this queue'),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Future<void> _cancel(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Leave queue?'),
        content: const Text('Your ticket will be cancelled and cannot be restored.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep ticket'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Leave queue'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await FirestoreService.instance.cancelTicket(ticket.id);
    if (context.mounted) Navigator.of(context).pop();
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.icon,
    required this.label,
    required this.value,
  });
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 13),
            Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w900,
            )),
            const SizedBox(height: 3),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}